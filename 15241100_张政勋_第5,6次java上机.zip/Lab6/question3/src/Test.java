interface Flyer{
	void fly();
	void takeoff();
	void land();
}

class Airplane implements Flyer{
	public void fly() {
		System.out.println("Airplane fly");
	}
	public void takeoff() {
		System.out.println("Airplane takeoff");
	}
	public void land() {
		System.out.println("Airplane land");
	}
}

class Bird implements Flyer{
	public void fly() {
		System.out.println("Bird fly");
	}
	public void takeoff() {
		System.out.println("Bird takeoff");
	}
	public void land() {
		System.out.println("Bird land");
	}
	public void buildNest() {
		System.out.println("Bird buildNest");
	}
	public void layEggs() {
		System.out.println("Bird layEggs");
	}
}

public class Test{
	public static void main(String args[]) {
		Airplane ar = new Airplane();
		ar.fly();ar.takeoff();
		Bird b = new Bird();
		b.buildNest(); b.land();
		Flyer f = new Bird();
		f.fly();
		((Bird)f).buildNest();
	}
}