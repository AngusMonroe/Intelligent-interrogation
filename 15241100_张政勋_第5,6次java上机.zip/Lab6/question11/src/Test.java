import java.util.Scanner;

public class Test
{
	static int calcSpace(String s){
		int ans = 0;
		for(int i = 0 ;i<s.length();i++){
			if(s.charAt(i) == ' ')
				ans++;
		}
		return ans;
	}
	static int calcNum(String s){
		int ans = 0;
		for(int i = 0 ;i<s.length();i++){
			if(s.charAt(i) >='0' && s.charAt(i) <='9')
				ans++;
		}
		return ans;
	}
	static int calcEnglish(String s){
		int ans = 0;
		for(int i = 0 ;i<s.length();i++){
			if((s.charAt(i) >= 'a' && s.charAt(i) <= 'z') || (s.charAt(i) >= 'A' && s.charAt(i) <= 'Z') )
				ans++;
		}
		return ans;
	}
	static int calcOther(String s){
		return s.length() - calcSpace(s) - calcNum(s) - calcEnglish(s);
	}
	
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		System.out.println("�ո����"+calcSpace(s));
		System.out.println("���ַ���"+calcNum(s));
		System.out.println("Ӣ�ķ���"+calcEnglish(s));
		System.out.println("��������"+calcOther(s));
	}
}
