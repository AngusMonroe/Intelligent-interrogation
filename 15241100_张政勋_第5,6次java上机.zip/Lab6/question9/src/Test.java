public class Test
{
	public static void main(String[] args)
	{
		System.out.println(Math.PI);
		System.out.println(Math.E);
		System.out.println(Math.sin(Math.PI));
		System.out.println(Math.sqrt(2.8));
		System.out.println(Math.pow(5.0, 2.0));
		System.out.println(Math.exp(1.2));
		System.out.println(Math.random() * 100);
		System.out.println(Math.signum(-3.4));
		System.out.println(Math.sqrt(4.0));
		System.out.println(Math.cbrt(27.0));
		System.out.println(Math.log(Math.E));
		System.out.println(Math.log10(230.0));
		System.out.println(Math.toDegrees(Math.PI));
		System.out.println(Math.toRadians(180.0));
		System.out.println(Math.abs(3.4));
		System.out.println(Math.ceil(9.9));
		System.out.println(Math.floor(12.2));
		System.out.println(Math.max(5,6));
		System.out.println(Math.min(1.5, 0.4));
		System.out.println(Math.round(2.5));
	}
}
