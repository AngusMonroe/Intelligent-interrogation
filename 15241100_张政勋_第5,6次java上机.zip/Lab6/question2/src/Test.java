
interface Flyer{
	void fly();
	void takeoff();
	void land();
}