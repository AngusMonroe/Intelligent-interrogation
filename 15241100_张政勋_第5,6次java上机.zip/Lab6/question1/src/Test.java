
abstract class Shape{
	abstract double area();
}

class Circle extends Shape {
	double r;
	double area() {
		return Math.PI * this.r * this.r;
	}
}

class Rectangle extends Shape {
	double x,y,z;
	double area() {
		double p = (double)(x+y+z)/2;
		double s = (double)Math.sqrt(p*(p-x)*(p-y)*(p-z));
		return s;
	}
}