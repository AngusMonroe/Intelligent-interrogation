public class Test
{
	public static void main(String[] args)
	{
		String s = "abcs";
		System.out.println(s.charAt(0));
		System.out.println(s.charAt(s.length()-1));
	}
}
