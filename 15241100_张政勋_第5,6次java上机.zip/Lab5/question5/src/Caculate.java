import java.util.Scanner;

class NumberRangeException extends Exception{
	int a;
	int b;
	NumberRangeException(int a, int b) {
		this.a = a;
		this.b = b;
	}
	public String toString() {
		return "operater numbers out of range:" + a + "," + b;
	}
}

public class Caculate {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Input a");
		int a = sc.nextInt();
		System.out.println("Input b");
		int b = sc.nextInt();
		try {
			System.out.println(add(a, b));
			System.out.println(sub(a, b));
		} catch (NumberRangeException e) {
			System.out.println(e.toString());
		}
	}
	
	static int add(int a, int b) throws NumberRangeException{
		if(a>10 || a<0 || b>10 || b<0)
			throw new NumberRangeException(a, b);
		return a+b;
	}
	
	static int sub(int a, int b) throws NumberRangeException {
		if(a>10 || a<0 || b>10 || b<0)
			throw new NumberRangeException(a, b);
		return a-b;
	}
}
