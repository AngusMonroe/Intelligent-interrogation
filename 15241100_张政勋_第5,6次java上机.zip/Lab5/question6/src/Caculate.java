import java.util.Scanner;

class NotTrangleException extends Exception {
	@Override
	public String toString() {
		String s= super.toString();
		s+= "�޷��γ�������";
		return s;
	}
}

class Triangle{
	int x,y,z;
	public Triangle(int a,int b,int c) throws NotTrangleException {
		if(!(a+b>c) || !(a+c>b) || !(b+c>a))
			throw new NotTrangleException();
		x= a; y = b; z=c;
	}
	double getArea() {
		double p = (double)(x+y+z)/2;
		double s = (double)Math.sqrt(p*(p-x)*(p-y)*(p-z));
		return s;
	}
	void showInfo(){
		System.out.println("three side:"+x+", "+y+", "+z);
	}
}

public class Caculate {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Input a");
		int a = sc.nextInt();
		System.out.println("Input b");
		int b = sc.nextInt();
		System.out.println("Input c");
		int c = sc.nextInt();
		try {
			Triangle t = new Triangle(a, b, c);
			t.showInfo();
			System.out.println(t.getArea());
		} catch (NotTrangleException e) {
			System.out.println(e.toString());
		}
	}
}
